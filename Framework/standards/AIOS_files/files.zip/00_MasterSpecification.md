# MUF Labs AI Operating System — Master Specification

**Version:** 2.0 (Refactored)
**Status:** Official Engineering Standard
**Applies To:** Entire MUF Labs Engineering Framework / AI Operating System (AIOS)
**Authority Level:** Framework Standard
**Supersedes:** `EngineeringWorkflow.md` v1.0 (monolithic, 17,116 lines, single file)

---

## 1. What this is

This is a modular respecification of the original `EngineeringWorkflow.md`, which had organically grown into a complete AI Operating System specification inside a single Markdown file. That growth produced duplicated sections, duplicated concepts, and unclear subsystem ownership. This document set restructures the same normative content — **every SHALL, SHOULD, and MAY statement from the original is preserved** — into 17 single-responsibility subsystem documents plus a glossary, index, and normative-reference appendix, following the editorial conventions of POSIX, the Linux Kernel documentation, Kubernetes SIG Architecture, and OpenAPI.

If you are looking for the original monolithic text, see the Migration Report for exactly where every section moved.

## 2. How to read this specification

- **New to the system?** Start with `02_AIOSCoreArchitecture.md` for the Vision & Philosophy and the layered architecture, then `01_EngineeringWorkflow.md` for the request/response contract every workflow follows.
- **Implementing a subsystem?** Go directly to its document (table below) and its Responsibility Matrix row to see exactly what it owns and what it must reference rather than restate.
- **Looking for a term?** Check `Appendix-A_Glossary.md`, or find any section by name in `Appendix-C_Index.md`.
- **Auditing the refactor itself?** See `Structural_Audit.md`, `Duplicate_Report.md`, `Migration_Report.md`, and `Traceability_Matrix.csv`.

## 3. Document map

| # | Document | Responsibility |
|---|---|---|
| 01 | [Engineering Workflow](01_EngineeringWorkflow.md) | The workflow request/response contract: participants, authority, lifecycle, inputs/outputs, prompting |
| 02 | [AIOS Core Architecture](02_AIOSCoreArchitecture.md) | The single global vision, philosophy, and layered architecture |
| 03 | [Kernel & Runtime](03_KernelRuntime.md) | Agent runtime, process/task/thread management, scheduling, system calls |
| 04 | [Resource Management](04_ResourceManagement.md) | Resource allocation, execution profiles, cost/latency policy, resilience, telemetry |
| 05 | [Tools & Services](05_ToolsAndServices.md) | Capabilities, providers, plugins, connectors, the AI Service Manager |
| 06 | [Applications & SDK](06_ApplicationsSDK.md) | AI-native applications, the Application Runtime, the AI SDK |
| 07 | [User Experience](07_UserExperience.md) | Configuration philosophy, interaction, explainability, accessibility |
| 08 | [Intelligence Engine](08_IntelligenceEngine.md) | Reasoning, swarm/adaptive intelligence, confidence, discovery |
| 09 | [Planning & Execution](09_PlanningExecution.md) | Decomposition, planning, execution, workflow composition, sessions |
| 10 | [Knowledge & Memory](10_KnowledgeMemory.md) | Memory architecture, Digital Twin, Knowledge Graph, MOS, KGS |
| 11 | [Communication](11_Communication.md) | Event Bus, Message Bus, KEP, KCP, endpoint discovery |
| 12 | [Hardware & Virtualization](12_HardwareVirtualization.md) | Hardware abstraction, compute virtualization, AIVL |
| 13 | [Language Specifications](13_LanguageSpecifications.md) | WDL, ADL, CDL formal grammars |
| 14 | [Object Models](14_ObjectModels.md) | The universal Engineering Object Specification (EOS) |
| 15 | [Packages & Services](15_PackagesServices.md) | The AI Package Specification (AIP), registry, Marketplace |
| 16 | [Governance & Security](16_GovernanceSecurity.md) | Security architecture, compliance, audit, the Policy Definition Language (PDL) |
| 17 | [Extensibility & Roadmap](17_ExtensibilityRoadmap.md) | Extensibility interfaces and forward-looking roadmap (non-normative) |

## 4. Appendices

- [Appendix A — Glossary](Appendix-A_Glossary.md)
- [Appendix B — Normative References](Appendix-B_NormativeReferences.md)
- [Appendix C — Index](Appendix-C_Index.md)

## 5. Refactoring audit trail

- [Structural Audit](Structural_Audit.md) — Phase 1 findings
- [Duplicate Report](Duplicate_Report.md) — Phase 2 KEEP/MERGE/REMOVE/MOVE decisions for all 17 exact-duplicate titles, plus the 4 global vision/philosophy statements
- [Responsibility Matrix](Responsibility_Matrix.md) — what each document owns, and the "Special Rules" applied
- [Domain Map](Domain_Map.md) — dependency layering and circular-dependency check
- [Migration Report](Migration_Report.md) — routing methodology, verification, and flagged follow-up work
- [Cross-Reference Report](Cross_Reference_Report.md) — every intentional inter-document reference
- [Traceability Matrix](Traceability_Matrix.csv) — every one of the 782 migrated sections, original line → new document/section

## 6. Governing principles (summary — see `02_AIOSCoreArchitecture.md` for the full statement)

- Zero duplicated sections, concepts, definitions, or introductions.
- Every subsystem owns exactly one responsibility; no circular dependencies.
- No normative requirement (SHALL/SHOULD/MAY) was dropped in this refactor — only relocated, merged, or (where an exact duplicate) reduced to a single canonical statement.
- Roadmap and architecture are kept separate: forward-looking material lives only in `17_ExtensibilityRoadmap.md`.
